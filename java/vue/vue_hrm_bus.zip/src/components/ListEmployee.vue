<template>
    <div>
        <ul>
            <li v-for="(propsItem) in emps" v-bind:key="propsItem.id" class="shadow">
                id : {{propsItem.id}} / name : {{propsItem.name}} / dept_id : {{propsItem.dept_id}} / salary : {{propsItem.salary}}
                 <button @click="removeEmp(propsItem.id)">삭제 </button>
            </li>
        </ul>
    </div>
</template>

<script>
import http from "../http-common";
import bus from "../eventBus";

    export default {
        name : 'EmpList',
        data(){
            return{
                emps:[]
            }
        },
        created() {
            this.getEmpList();
            bus.$on("getEmpList",this.getEmpList);
        },
        methods: {
            getEmpList() {
                http.get('/api/findAllEmployees')
                .then((response)=>{
                    this.emps = response.data.data;
                    console.log(response.data.data);
                    })
                .catch(exp=>alert('처리에 실패하였습니다.'+exp));   
            },
            removeEmp(key) {
                http.delete('/api/deleteEmployee/'+key)
                .then(()=>{
                    console.log("delete()......");
                    this.getEmpList();
                })
                .catch(exp=>alert('삭제 처리에 실패하였습니다.'+exp));   
            }
        }
    }
</script>

<style scoped>

</style>