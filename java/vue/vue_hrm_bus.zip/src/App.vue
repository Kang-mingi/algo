<template>
  <div id="app">
    <add-employee></add-employee>
    <list-employee></list-employee>
  </div>
</template>

<script>
import AddEmployee from './components/AddEmployee.vue';
import ListEmployee from './components/ListEmployee.vue';

export default {
  name: 'app',
  components: {
    AddEmployee,
    ListEmployee
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
