export default{
    GET_TODOLIST : 'getTodoList',
    GET_TODO : 'getTodo',
    ADD_TODO : 'addTodo',
    MODIFY_TODO : 'modifyTodo',
    REMOVE_TODO : 'removeTodo',
    COMPLETE_TODO : 'completeTodo', //UPDATE_TODO
    CLEAR_TODO : 'clearTodo',
    UPDATE_TODO : 'updateDone'
}