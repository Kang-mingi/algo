import Vue from 'vue';
import Vuex from 'vuex';
import Constant from './Constant';
import http from './http-common';

Vue.use(Vuex);
const store = new Vuex.Store({
    state:{
        todoItems : [],
        todo : {},
    },
    actions: {
        //[] : 안에 쓰인 표현식을 실행해서 결과값을 속성명으로 치환 (getTodoList)
        [Constant.GET_TODOLIST] : (store) => {
            http
              .get("/todolist/user/java")
              .then(response => {
                store.commit(Constant.GET_TODOLIST, {todoItems : response.data});
                console.log(response.data);
              })
              .catch(exp => alert("처리에 실패하였습니다." + exp));
          },
          [Constant.REMOVE_TODO] : (store, payload) => {
            http.delete("/todolist/todo/" + payload.no)
              .then(() => {
                  console.log("삭제 처리되었습니다. #"+payload.no);
                  store.dispatch(Constant.GET_TODOLIST);
              })
              .catch(exp => alert("삭제 처리에 실패하였습니다." + exp));
          },
          [Constant.UPDATE_TODO] : (store,payload) => {
            http
              .put("/todolist/todo/done/" + payload.no)
              .then(() => {
                console.log("updateDone" + payload.no);
                store.dispatch(Constant.GET_TODOLIST);
              })
              .catch(exp => alert("완료 처리에 실패하였습니다." + exp));
          },
          [Constant.ADD_TODO] : (store, payload) => {
            http
              .post("/todolist/todo", {
                content: payload.todo.content,
                endDate: payload.todo.endDate,
                userId: "java"
              })
              .then(() => {
                console.log("등록 처리에 성공하였습니다.");
                store.dispatch(Constant.GET_TODOLIST);
              })
              .catch(exp => alert("등록 처리에 실패하였습니다." + exp));
          }
    },
    mutations: {    //저장소에 데이터 실제 반영(commit시 호 출)
        [Constant.GET_TODOLIST] : (state, payload) => {
            store.state.todoItems = payload.todoItems;
        }
    }
});

export default store;