<template>
    <div class='detail'>
        <br/>
        <b>상세보기</b> <br/>
        <table>
            <tr>
                <td>no</td>
                <td>{{todo.no}}</td>
            </tr>
            <tr>
                <td>content</td>
                <td>{{todo.content}}</td>
            </tr>
            <tr>
                <td>userid</td>
                <td>{{todo.userId}}</td>
            </tr>
            <tr>
                <td>wirteDate</td>
                <td>{{todo.writeDate}}</td>
            </tr>
            <tr>
                 <td>endDate</td>
                <td>{{todo.endDate}}</td>
            </tr>
            <tr>
                <td>done</td>
                <td>{{todo.done}}</td>
            </tr>
                
        </table>
    </div>
</template>


<script>
import Constant from '../Constant';

    export default {
        computed: {
            todo() {
                return this.$store.state.todo;
            }
        },
        created () {
            //route의 param미터들 중 'no' 라는 속성
            // console.log(this.$route.params.no);
            this.getTodo();
        },
        methods: {
            getTodo() {
                this.$store.dispatch(Constant.GET_TODO,{no: this.$route.params.no});
            }
        },
    }
</script>



<style scoped>
table{
    width : 50%;
}
table, tr, td{
    margin : auto;
    border : 1px solid;
    border-collapse: collapse;
}
</style>