<template>
    <header>
        <img src="../assets/logo.png" />
        <h1>Todo List - Vuex Rotuer </h1>
        <div>
            <router-link to="/input">추 가</router-link>
            &nbsp; &nbsp; &nbsp; &nbsp; 
            <router-link to="/list">목 록</router-link>
        </div>
    </header>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    h1{
        color : #2f3b52;
        font-weight: 900;
        margin : 2.5rem 1.5rem;
    }
</style>