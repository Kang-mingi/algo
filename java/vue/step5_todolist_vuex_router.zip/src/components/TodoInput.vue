<template>
  <div class="inputBox">
    할일 입력 :
    <input type="text" class="todoName" v-model="todo.content" />
    기한 :
    <input type="date" class="todoDate" v-model="todo.endDate" />
    <span @click="addTodo()" class="addContainer">
      <div class="addBtn fas fa-plus"></div>
    </span>
  </div>
</template>

<script>
import Constant from '../Constant';
export default {
  name: "TodoMaker",
  data() {
    return {
      todo: {
        content:"",
        endDate:"",
        no: 0
      }
    };
  },
  methods: {
    addTodo() {
      if (this.todo.content.trim() != "") {
        this.$router.push("/list");
        this.$store.dispatch(Constant.ADD_TODO, {todo: this.todo});
        this.clear();
      }
    },
    clear() {
      this.todo.content = "";
      this.todo.endDate = "";
    }
  },
  // todoList는 과거의 리스트만 보여주기 때문에 데이터가 바뀌었다고
  // 통신을 해야한다.
};
</script>

<style>
input:focus {
  outline: none;
}
.inputBox {
  margin: 0.5rem 0;
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #6478fb, #8763fb);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addContainer2 {
  float: right;
  background: linear-gradient(to right, #647811, #527810);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.modifyBtn,
.addBtn {
  color: white;
  vertical-align: middle;
}
</style>