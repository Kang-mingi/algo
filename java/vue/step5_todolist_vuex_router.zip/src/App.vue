<template>
  <div id="app">
    <todo-header></todo-header>
    <!-- <todo-input></todo-input>
    <todo-list></todo-list> -->
    <!-- <router-view name="a"></router-view> -->
    <router-view></router-view>
  </div>
</template>

<script>
import TodoList from "./components/TodoList.vue";
import TodoHeader from "./components/TodoHeader.vue";
import TodoInput from "./components/TodoInput.vue";
import TodoDetail from "./components/TodoDetail.vue";
import VueRouter from 'vue-router';
import Vue from 'vue';

Vue.use(VueRouter);

const router = new VueRouter({
  mode:'history',
  routes:[
    { path : '/', component:TodoList},    //라우팅 정보 하나씩 갖고있는 객체, '/' = default
    { path : '/list', component:TodoList},
    { path : '/input', component:TodoInput},
    { path : '/detail/:no', component:TodoDetail}

    //router-view가 같은 level에서 2개 이상일 경우 name을 주고 동시에 라우팅 가능
    // { path : '/detail/:no', components: {
    //     a: TodoList,
    //     default: TodoDetail
    //   }
    // }
  ]
})

export default {
  name: "app",
  components: {
    // TodoList, 
    TodoHeader,
    // TodoInput
  },
  router    //router : router
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
body {
  text-align: center;
  background-color: #f6f6f8;
}
input {
  border-style: groove;
  width: 200px;
}
button {
  border-style: groove;
}
.shadow {
  box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.03);
}
</style>