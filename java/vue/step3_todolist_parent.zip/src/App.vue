<template>
  <div id="app">
    <todo-header></todo-header>

    <!-- @event명="함수명" -->
    <todo-add @addTodoList="addTodoList"></todo-add>
    <todo-list :propsTodoItems="todoItems" @removeTodo="removeTodo" @updateDone="updateDone"></todo-list>
  </div>
</template>

<script>
import TodoList from './components/TodoList.vue';
import TodoHeader from './components/TodoHeader.vue';
import TodoAdd from './components/TodoAdd.vue';
import http from "./http-common";

export default {
  name: 'app',
  components: {
    TodoList,TodoHeader,TodoAdd
  },
  data(){
    return{
      todo: {},
      todoItems:[]
    }
  },
  mounted () {
    this.getTodoList();
  },
  methods: {
    getTodoList() {
       http.get('/todolist/user/java')
       .then((response)=>{
         this.todoItems = response.data;
         console.log("getTodoList()......");
        })
       .catch(exp=>alert('처리에 실패하였습니다.'+exp));   
   },
   removeTodo(key) {
       http.delete('/todolist/todo/'+key)
      //  .then((response)=>this.todoItems = response.data)
       .then(()=>{
        this.getTodoList();
      })
       .catch(exp=>alert('삭제 처리에 실패하였습니다.'+exp));   
   },
   updateDone(key) {
       http.put('/todolist/todo/done/'+key)
      //  .then((response)=>this.todoItems = response.data)
      .then(()=>{
        this.getTodoList();
      })
       .catch(exp=>alert('완료 처리에 실패하였습니다.'+exp));   
   },
   addTodoList(todo) {
      http.post('/todolist/todo', {
        content:todo.content
        ,endDate:todo.endDate
        ,userId:'java'
      })
        .then(()=>{
          console.log('등록 처리에 성공하였습니다.');
          this.getTodoList();
          // window.location.reload();
        })
        .catch(exp=>alert('등록 처리에 실패하였습니다.'+exp));
   },
  },
}

</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
body {
    text-align: center;
    background-color: #F6F6F8;
  }
  input {
    border-style: groove;
    width: 200px;
  }
  button {
    border-style: groove;
  }
  .shadow {
    box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.03)
  }
</style>
