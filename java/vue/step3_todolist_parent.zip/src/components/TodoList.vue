<template>
  <div>
    <ul>
      <li v-for="(todoItem) in propsTodoItems" v-bind:key="todoItem.no" class="shadow" :class="{done:todoItem.done=='Y'}">
        <p v-on:click="updateDone(todoItem.no)">
          <i v-if="todoItem.done == 'N'" class="checkBtn fas fa-check" ></i>
          {{todoItem.content}} : {{todoItem.endDate}} 
        </p>
        <span
          class="removeBtn"
          type="button">
          <i class="far fa-trash-alt" v-on:click="removeTodo(todoItem.no)"></i>
        </span>
      </li>
    </ul>
  </div>
</template>

<script>

export default {
  name : 'TodoList',
  props: {
    propsTodoItems: {
      type: Array
    },
  },
  methods: {
   removeTodo(key) {
     console.log('removeTodo......'+key);
     this.$emit('removeTodo', key);
   },
   updateDone(key) {
     console.log('updateDone......'+key);
     this.$emit('updateDone', key);
   }
  }
};
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>