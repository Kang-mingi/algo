<template>
    <header>
        <img src="../assets/logo.png" />
        <h1>Todo List - Parent Component </h1>

    </header>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    h1{
        color : #2f3b52;
        font-weight: 900;
        margin : 2.5rem 1.5rem;
    }
</style>