<template>
  <div>
    <form>
        <input type="text" name='cotent'  v-model='todoItem.content' placeholder="cotent"/>&nbsp;
        <input type="date" name='endDate' v-model='todoItem.endDate' placeholder="enddate"/>&nbsp;
        <input type="button" v-on:click="addTodoList()" value="등록"/>
    </form>
  </div>
</template>

<script>
import http from "../http-common";

export default {
  name : 'TodoAdd',
  data() {
    return {
      todoItem : {
        content: ""
        ,userId:"java"
        ,writeDate:""
        ,endDate:""
        ,done:"N" 
      }
      
    };
  },
  methods: {
   addTodoList() {
       http.post('/todolist/todo', this.todoItem)
      //  .then((response)=>this.todoItems = response.data)
      //  .then(()=>alert('등록되었습니다.'))
      .then(function(){
         window.location.reload();
       })
       .catch(exp=>alert('등록 처리에 실패하였습니다.'+exp));
   },
  }
};
</script>

<style scoped>

</style>