<template>
  <div class="inputBox">
    <form>
        할 일 입력 : <input type="text" name='cotent'  v-model='todoItem.content' placeholder="할 일"/>
        기한 : <input type="date" name='endDate' v-model='todoItem.endDate' placeholder="enddate"/>
        <span class="addContainer" v-on:click="addTodoList()">
          <div class="addBtn fas fa-plus"></div>
        </span>
    </form>
  </div>
</template>

<script>
import http from "../http-common";
import bus from "../eventBus";

export default {
  name : 'TodoAdd',
  data() {
    return {
      todoItem : {
        content: ""
        ,userId:"java"
        ,writeDate:""
        ,endDate:""
        ,done:"N" 
      }
      
    };
  },
  methods: {
   addTodoList() {
      if(this.todoItem.content.trim() != ''){
        http.post('/todolist/todo', {
          content:this.todoItem.content
          ,endDate:this.todoItem.endDate
          ,userId:'java'
        })
        .then(()=>{
          console.log('등록 처리에 성공하였습니다.');
          bus.$emit("getTodoList");
          this.clear();
          // window.location.reload();
        })
        .catch(exp=>alert('등록 처리에 실패하였습니다.'+exp));
      }
      
   },
   clear(){
     this.todoItem.content="";
     this.todoItem.endDate="";
   }
  }
};
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #6478FB, #8763FB);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addContainer2 {
  float: right;
  background: linear-gradient(to right, #647811, #527810);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.modifyBtn, .addBtn {
  color: white;
  vertical-align: middle;
}


</style>