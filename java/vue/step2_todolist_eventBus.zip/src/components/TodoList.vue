<template>
  <div>
    <ul>
      <li v-for="(todoItem) in todoItems" v-bind:key="todoItem.no" class="shadow" :class="{done:todoItem.done=='Y'}">
        <p v-on:click="updateDone(todoItem.no)">
          <i v-if="todoItem.done == 'Y'" class="checkBtn fas fa-check" ></i>
          {{todoItem.content}} : {{todoItem.endDate}} 
        </p>
        <span
          class="removeBtn"
          type="button">
          <i class="far fa-trash-alt" v-on:click="removeTodo(todoItem.no)"></i>
        </span>
      </li>
    </ul>
  </div>
</template>

<script>
import http from "../http-common";
import bus from "../eventBus";

export default {
  name : 'TodoList',
  data() {
    return {
      todoItems: []
    };
  },
  created() {
    this.getTodoList();
    bus.$on("getTodoList",this.getTodoList);
  },
  methods: {

   getTodoList() {
       http.get('/todolist/user/java')
       .then((response)=>{
         this.todoItems = response.data;
         console.log(response.data);
        })
       .catch(exp=>alert('처리에 실패하였습니다.'+exp));   
   },
   removeTodo(key) {
       http.delete('/todolist/todo/'+key)
      //  .then((response)=>this.todoItems = response.data)
       .then(function(){
         window.location.reload();
       })
       .catch(exp=>alert('삭제 처리에 실패하였습니다.'+exp));   
   },
   updateDone(key) {
       http.put('/todolist/todo/done/'+key)
      //  .then((response)=>this.todoItems = response.data)
      .then(function(){
         window.location.reload();
       })
       .catch(exp=>alert('완료 처리에 실패하였습니다.'+exp));   
   }
  }
};
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>