<template>
    <div>
        <ul>
            <li v-for="(propsItem) in propsItems" v-bind:key="propsItem.id" class="shadow">
                id : {{propsItem.id}} / name : {{propsItem.name}} / dept_id : {{propsItem.dept_id}} / salary : {{propsItem.salary}}
                 <button @click="removeEmp(propsItem.id)">삭제 </button>
            </li>
        </ul>
    </div>
</template>

<script>
    export default {
        name : 'EmpList',
        props: {
            propsItems: {
                type: Array
            },
        },
        methods: {
            removeEmp(key) {
                console.log('removeEmp......'+key);
                this.$emit('removeEmp', key);
            }
        }
    }
</script>

<style scoped>

</style>