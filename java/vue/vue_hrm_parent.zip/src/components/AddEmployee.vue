<template>
    <div>
    <table asign="center">
      <tr>
        <td>사원 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.name" />
        </td>
      </tr>
      <tr>
        <td>메일ID :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.mailid" />
        </td>
      </tr>
      <tr>
        <td>입사일 :</td>
        <td>
          <input type="date" class="inputBox" v-model="employee.start_date" />
        </td>
      </tr>
      <tr>
        <td>매니저 :</td>
        <td>
          <input type="number" class="inputBox" v-model="employee.manager_id" />
        </td>
      </tr>
      <tr>
        <td>직급 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.title" />
        </td>
      </tr>
      <tr>
        <td>부서ID :</td>
        <td>
          <input type="number" class="inputBox" v-model="employee.dept_id" />
        </td>
      </tr>
      <tr>
        <td>연봉 :</td>
        <td>
          <input type="number" class="inputBox" v-model="employee.salary" />
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <input type="button" value="입력" class="modifyBtn" @click="addEmployee()" />
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
    export default {
        name : 'emp',
        data() {
            return {
            employee : {
                name : ""
                ,mailid : ""
                ,start_date : ""
                ,manager_id : ""
                ,title : ""
                ,dept_id : ""
                ,salary : ""
            }
            
            };
        },
        methods: {
            addEmployee(){
                if(this.employee.name.trim() != ''){
                    this.$emit("addEmployee", this.employee);
                    // this.clear();
                }
            },
            clear(){
                this.employee.name="";
                this.employee.mailid="";
                this.employee.manager_id="";
                this.employee.title="";
                this.employee.dept_id="";
                this.employee.salary="";
            }
        }
    }
</script>

<style scoped>

</style>