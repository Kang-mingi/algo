<template>
  <div id="app">
    <add-employee @addEmployee="addEmployee"></add-employee>
    <list-employee :propsItems="emps" @removeEmp="removeEmp"></list-employee>
  </div>
</template>

<script>
import AddEmployee from './components/AddEmployee.vue';
import ListEmployee from './components/ListEmployee.vue';
import http from "./http-common";

export default {
  name: 'app',
  components: {
    AddEmployee,
    ListEmployee
  },
  data(){
    return{
      emp:{},
      emps:[]
    }
  },
  mounted () {
    this.getEmpList();
  },
  methods: {
    getEmpList() {
       http.get('/api/findAllEmployees')
       .then((response)=>{
         console.log("getEmpList()......");
         this.emps = response.data.data;
        })
       .catch(exp=>alert('처리에 실패하였습니다.'+exp));   
   },
   removeEmp(key) {
       http.delete('/api/deleteEmployee/'+key)
      //  .then((response)=>this.todoItems = response.data)
       .then(()=>{
        this.getEmpList();
      })
       .catch(exp=>alert('삭제 처리에 실패하였습니다.'+exp));   
   },
   addEmployee(emp) {
      http.post('/api/addEmployee', emp)
        .then(()=>{
          this.getEmpList();
          // window.location.reload();
        })
        .catch(exp=>alert('등록 처리에 실패하였습니다.'+exp));
   },
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
