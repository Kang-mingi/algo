package com.ssafy.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.dto.Department;
import com.ssafy.model.dto.Employee;
import com.ssafy.service.EmployeeService;

import io.swagger.annotations.ApiOperation;

/*
 * @RestController
 * Restful 서비스를 위한 컨트롤로러 @ResponseBody 어노테이션을 추가하지 않아도
 * 기본적으로 직접 출력 해 준다
 * */
@CrossOrigin("*")
@RestController
public class EmployeeRestController {
	@Autowired
	private EmployeeService service;
	
	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> handle(Exception e){
		return handleFail(e.getMessage(), HttpStatus.OK);
	}
	
	@ApiOperation("!!")
	@GetMapping("/api/findDeptByIdWithEmployees/{id}")
	public  ResponseEntity<Map<String, Object>> findDeptByIdWithEmployees(@PathVariable int id) throws Exception{
		Department dept = service.findDeptByIdWithEmployees(id);
		return handleSuccess(dept);
	}
	
	
	@ApiOperation("새로운 사원의 정보를 입력한다. 그리고 그 사원의 사원번호를 반환한다")
	@PostMapping("/api/addEmployee")
	public ResponseEntity<Map<String, Object>> add(@RequestBody Employee employee){
		service.insert(employee);
		return handleSuccess("등록 완료");
	}
	
	@ApiOperation("해당사원의 정보를 삭제한다.사원의 정보를 삭제하기전, 정산하고, 잡히스토리 수정등 여러 작업을 해야한다. 여기서는 히스토리를 모두 지우고(수정한 적이 없다면 바로 삭제 가능)삭제할 수 있다.")
	@DeleteMapping("api/deleteEmployee/{employeeId}")
	public ResponseEntity<Map<String, Object>> delete(@PathVariable String employeeId){
		service.delete(employeeId);
		return handleSuccess("삭제 완료");
	}
	
	@ApiOperation("모든 사원의 수를 반환한다.")
	@GetMapping("/api/findAllEmployees")
	public ResponseEntity<Map<String, Object>> employee(){
		List<Employee> list = service.searchAll();
		return handleSuccess(list);
	}
	
	@ApiOperation("모든 부서의 정보를 반환한다.")
	@GetMapping("/api/findAllDepartments")
	public ResponseEntity<Map<String, Object>> department(){ 
		List<Department> list = service.searchdepart();
		return handleSuccess(list);
	}
	
	@ApiOperation("사원아이디로 사원의 정보를 찾는다.")
	@GetMapping("/api/findEmployeeById/{id}")
	public ResponseEntity<Map<String, Object>> searchid(@PathVariable int id){
		return handleSuccess(service.searchid(id));
	}
	
	@ApiOperation("이름의 일부분에 해당하는 사원의 정보를 반환한다.")
	@GetMapping("/api/findLikeEmployees/{name}")
	public ResponseEntity<Map<String, Object>> searchid(@PathVariable String name){
		return handleSuccess(service.searchname(name));
	}
	
	@ApiOperation("모든 직책을 반환한다.")
	@GetMapping("/api/findAllTitles")
	public ResponseEntity<Map<String, Object>> title(){
		return handleSuccess(service.title());
	}
	
	@ApiOperation("모든 사원의 수를 반환한다.")
	@GetMapping("/api/getEmployeesTotal")
	public ResponseEntity<Map<String, Object>> count(){
		return handleSuccess(service.count());
	}
	
	@ApiOperation("사원의 정보를 수정한다 만약 사원의 부서와 업무가 변경되면 잡히스토리에 자동(trigger)으로 추가된다.")
	@PutMapping("/api/updateEmployee")
	public ResponseEntity<Map<String, Object>> update(@RequestBody Employee employee){
		service.update(employee);
		return handleSuccess("수정 완료");
	}
	
	public ResponseEntity<Map<String, Object>> handleFail(Object data, HttpStatus state){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "fail");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String,Object>>(resultMap, state);
	}
	public ResponseEntity<Map<String, Object>> handleSuccess(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "ok");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
	
}
