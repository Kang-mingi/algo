package com.ssafy.model.dto;

import java.util.List;

public class Department {
	int dept_id;
	String name;
	int region_id;
	List<Employee> employees;
	
	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public Department() {}

	public Department(int dept_id, String name, int region_id) {
		super();
		this.dept_id = dept_id;
		this.name = name;
		this.region_id = region_id;
	}

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRegion_id() {
		return region_id;
	}

	public void setRegoin_id(int region_id) {
		this.region_id = region_id;
	}

	@Override
	public String toString() {
		return "Department [dept_id=" + dept_id + ", name=" + name + ", region_id=" + region_id + "]";
	};
	
	
	
}
