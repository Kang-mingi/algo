package com.ssafy.service;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.model.dto.Department;
import com.ssafy.model.dto.Employee;

public interface EmployeeService {
	public void insert(Employee employee);
	public void update(Employee employee);
	public void delete(String id);
	public List<String> title();
	public Employee searchid (int id);
	public List<Employee> searchname (String name);
	public int count();
	public List<Employee> searchAll();
	public List<Department> searchdepart();
	
	public Department findDeptByIdWithEmployees(int id) throws Exception;
}
