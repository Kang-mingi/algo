package com.ssafy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.EmployeeDao;
import com.ssafy.model.dto.Department;
import com.ssafy.model.dto.Employee;
import com.ssafy.model.dto.UpdateException;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao;
	public void insert(Employee employee) {
		try {
			dao.insert(employee);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 정보 입력 중 오류 발생");
		}
	}

	public void update(Employee employee) {
		try {
			dao.update(employee);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 정보 수정 중 오류 발생");
		}
	}

	public void delete(String id) {
		try {
			dao.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 정보 삭제 중 오류 발생");
		}
	}

	public List<String> title() {
		try {
			return dao.title();
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 title 조회 중 오류 발생");
		}
	}

	public Employee searchid(int id) {
		try {
			return dao.searchid(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 id 조회 중 오류 발생");
		}	
	}

	public List<Employee> searchname(String name) {
		try {
			return dao.searchname(name);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 name 조회 중 오류 발생");
		}
	}

	public int count() {
		try {
			return dao.count();
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 count 조회 중 오류 발생");
		}
	}

	public List<Employee> searchAll() {
		try {
			return dao.searchAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("사원 목록 조회 중 오류 발생");
		}
	}

	public List<Department> searchdepart() {
		try {
			return dao.searchdepart();
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("department 정보 조회 중 오류 발생");
		}
	}

	@Override
	public Department findDeptByIdWithEmployees(int id) throws Exception {
		try {
			return dao.findDeptByIdWithEmployees(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UpdateException("department 정보 조회 중 오류 발생");
		}
	}

}
