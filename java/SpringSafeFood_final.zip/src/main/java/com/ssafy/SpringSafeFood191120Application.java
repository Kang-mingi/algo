package com.ssafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSafeFood191120Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSafeFood191120Application.class, args);
	}

}
