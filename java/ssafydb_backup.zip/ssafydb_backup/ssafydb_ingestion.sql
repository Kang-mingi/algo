-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ingestion`
--

DROP TABLE IF EXISTS `ingestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `ingestion` (
  `ino` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `ingdate` datetime DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`ino`),
  KEY `code_idx` (`code`),
  KEY `id` (`id`),
  CONSTRAINT `code` FOREIGN KEY (`code`) REFERENCES `food` (`code`),
  CONSTRAINT `id` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingestion`
--

LOCK TABLES `ingestion` WRITE;
/*!40000 ALTER TABLE `ingestion` DISABLE KEYS */;
INSERT INTO `ingestion` VALUES (49,'ssafy',8,'2019-11-08 14:12:29',1),(52,'ssafy',18,'2019-11-08 14:13:14',1),(53,'jaen',1,'2019-11-25 15:26:38',1),(54,'jaen',1,'2019-11-25 15:26:47',1),(55,'jaen',1,'2019-11-25 15:26:49',1),(56,'jaen',1,'2019-11-25 15:26:49',1),(58,'jaen',1,'2019-11-25 15:27:53',1),(59,'jaen',1,'2019-11-25 15:27:53',1),(60,'jaen',1,'2019-11-25 15:27:53',1),(63,'jaen',1,'2019-11-25 15:27:54',1),(71,'ssafy',6,'2019-11-26 10:27:58',1),(72,'ssafy',1,'2019-11-29 00:00:00',2),(81,'ssafy',2,'2019-11-26 10:42:43',1),(85,'ssafy',3,'2019-11-29 00:00:00',2),(92,'ssafy',15,'2017-11-26 00:00:00',3),(93,'ssafy',10,'2019-11-26 00:00:00',2),(103,'root',10,'2019-11-27 13:09:21',1),(104,'root',11,'2019-11-27 13:09:27',1),(124,'sangmin',1,NULL,1),(129,'taemin',15,NULL,1),(130,'taemin',6,NULL,1),(131,'taemin',16,NULL,1),(136,'kmandu',6,'2019-11-27 18:41:35',1),(137,'kmandu',3,'2019-11-27 18:41:36',1),(139,'kmandu',14,'2019-11-27 18:46:08',1),(140,'hyy',10,NULL,1),(141,'hyy',1,NULL,1),(142,'hyy',3,NULL,1),(143,'hyy',11,NULL,1),(145,'asd',10,'2019-11-05 00:00:00',2),(146,'root',10,'2019-11-28 16:36:57',1),(147,'ssafy',10,'2019-11-29 00:00:00',2),(149,'kmandu',10,'2019-11-28 16:53:17',1),(153,'ssafy',3,'2019-11-25 18:54:24',1),(154,'ssafy',10,'2019-10-30 00:00:00',3),(155,'root',6,'2019-11-29 10:58:27',1),(156,'root',1,'2019-11-19 00:00:00',1),(157,'회원가입',10,'2019-11-29 11:02:08',1),(158,'ssafy',12,'2019-11-26 16:31:01',1),(159,'ssafy',10,'2019-11-05 00:00:00',3),(160,'ssafy',18,'2019-11-26 18:09:59',1),(161,'ssafy',11,'2019-11-12 00:00:00',3),(162,'ssafy',5,'2019-11-26 18:10:02',1),(163,'ssafy',3,'2019-11-27 14:42:20',1);
/*!40000 ALTER TABLE `ingestion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:12
