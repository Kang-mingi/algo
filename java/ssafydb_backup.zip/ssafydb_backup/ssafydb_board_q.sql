-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board_q`
--

DROP TABLE IF EXISTS `board_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `board_q` (
  `bno` int(11) NOT NULL AUTO_INCREMENT,
  `sno` int(11) DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `contents` varchar(3000) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bregdate` datetime NOT NULL,
  `hits` int(11) DEFAULT NULL,
  `goods` int(11) DEFAULT NULL,
  `uid` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`bno`),
  KEY `uid` (`uid`),
  CONSTRAINT `board_q_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_q`
--

LOCK TABLES `board_q` WRITE;
/*!40000 ALTER TABLE `board_q` DISABLE KEYS */;
INSERT INTO `board_q` VALUES (1,2,'아니 왜 이 음식은 없죠??','<br><br><img src=\"http://followmarket.co.kr/web/product/big/201804/7460_shop1_238998.jpg\" width=\"300\" height=\"300\"> <br><br>제가 제일 좋아하는 홈런볼이 없네요 ㅡ,.ㅡ ;; <br><br> 빨리 추가해주세요!!!','2019-11-25 14:36:08',96,3,'ssafy'),(39,1,'[긴급공지] 서버 점검 안내','<br><br>저희 웹사이트는 서버 점검 작업을 위해 <span style=\"color:red\">19-11-28 19:00 ~ 19-11-30 18:00 </span> 사이에 접속하실 수 없습니다. <br><br> 이용에 불편을 드려 정말 죄송합니다.<br><br>','2019-11-25 14:38:01',35,0,'root'),(41,1,'공지사항 2','<br><br>저희 웹사이트는 서버 점검 작업을 위해 테스트 작업 중입니다. <br> <span style=\"color:red\">19-11-28 19:00 ~ 19-11-30 18:00 </span> 사이에 접속하실 수 없습니다. <br><br> 이용에 불편을 드려 정말 죄송합니다.<br><br>','2019-11-25 18:45:16',29,0,'root'),(54,2,'데이터가 너무 적은거 같아요','안그럼??','2019-11-25 19:56:08',11,0,'jaen'),(60,2,'아메리카노 추천좀','전 칸타타 픽 ㅇㅈ하세요?','2019-11-28 15:27:32',1,0,'hkh');
/*!40000 ALTER TABLE `board_q` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:13
