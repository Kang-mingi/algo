-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board_a`
--

DROP TABLE IF EXISTS `board_a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `board_a` (
  `bno` int(11) NOT NULL AUTO_INCREMENT,
  `sno` int(11) DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `contents` varchar(3000) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bregdate` datetime NOT NULL,
  `hits` int(11) DEFAULT NULL,
  `goods` int(11) DEFAULT NULL,
  `uid` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `qno` int(11) NOT NULL,
  PRIMARY KEY (`bno`),
  KEY `uid` (`uid`),
  KEY `qno` (`qno`),
  CONSTRAINT `board_a_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `board_a_ibfk_2` FOREIGN KEY (`qno`) REFERENCES `board_q` (`bno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_a`
--

LOCK TABLES `board_a` WRITE;
/*!40000 ALTER TABLE `board_a` DISABLE KEYS */;
INSERT INTO `board_a` VALUES (3,2,'상민이는','ㄹㅇㄹㅇ 진짜 홈런볼이 없는게 말이 되냐?','2019-11-20 19:30:27',2,9,'ssafy',1),(4,2,'민기는','말은 돼지 ㅋㅋㅋ','2019-11-20 19:30:27',3,3,'jaen',1),(6,2,'11','말 == 돼지 ?','2019-11-20 15:49:07',1,2,'hkh',1),(8,2,'','HKH 노잼 ;;','2019-11-22 11:13:32',0,29,'hyy',1),(49,2,'','맞아요 진짜','2019-11-28 15:27:51',0,0,'hkh',54),(50,2,'','빠른 시일내 추가하도록 하겠습니다. 죄송합니다.','2019-11-28 15:28:15',0,3,'root',54),(51,2,'','ㅇ ㅇㅈ','2019-11-28 16:46:17',0,1,'ssafy',60),(52,2,'','아니요','2019-11-28 16:48:46',0,0,'ssafy',60);
/*!40000 ALTER TABLE `board_a` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:13
