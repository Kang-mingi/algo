-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `allergy` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `best_quiz_score` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1등이었던 아이디','1111','HKH','송도','airaider@naver.com','010','대두, 땅콩, 우유, 소고기, 돼지고기, ',250),('asd','asd','dd','asd','asd','12','게, 닭고기, 돼지고기, ',0),('heedu','heedu','희주','멀티캠퍼스','ssafy','010','우유, ',0),('hkh','1234','red hong','red','red@naver.com','010','새우, 연어, 민들레, ',0),('hyy','hyy','hyy','?왜알려줘야하죠','asdf','01012345678','대두, 땅콩, 우유, 게, 새우, 참치, 연어, 쑥, 소고기, 닭고기, 돼지고기, 복숭아, 민들레, 계란흰자',0),('jaen','1234','jaen','seoul','saen@ssafy.com','01098765432',NULL,0),('juyeon','1004','김주연','서울 관악구','wjg365@naver.com','010-5579-6454','땅콩, 게, 새우, 닭고기, 돼지고기, ',0),('kmandu','1234','강민기','kmandu2','kmandu1','01032880619','',0),('root','root','관리자계정','어제도 연가시 뼛다구 피에로 527번길 80, 107동','root@gamil.com','01012345678','대두, 땅콩, 우유, 게, 새우, 참치, 연어, 쑥, 소고기, 닭고기, 돼지고기, 복숭아, 민들레, 계란흰자',0),('sangmin','123','이상민','asdklakd;lqwdqw','dwqdjqwpoj@fjwq.com','010156165','대두, 땅콩, 소고기, 닭고기, ',0),('ss','ss','ss','11','111','11','',0),('ssafy','1234','이상민','경기도 용인시시시ㅣ','sm0514sm@mgail.com','01023232','땅콩, 게, 새우, 닭고기, 돼지고기',0),('taemin','taemin','태민쓰','서울 강남구','taeminkim23@gmail.com','01099743619','',0),('김주희','1234','12345','1234','1234','1234','대두, 땅콩, 우유',0),('샤이니','123','그만','서울','yyyyyy','010','게, ',0),('파수꾼','123','123','123','123','123','',0),('회원가입','123','회원가입','kawodwk q-pkfwk fwqpkfwq ','sm5051015@fmsos.cim123221','10101010','대두, 땅콩, 쑥, 소고기, 닭고기, 계란흰자',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:14
