-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `goods` (
  `gno` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(100) COLLATE utf8_bin NOT NULL,
  `price` int(11) DEFAULT '0',
  `maker` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `image` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `info` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `cno` char(2) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`gno`),
  KEY `fk_goods_cno` (`cno`),
  CONSTRAINT `fk_goods_cno` FOREIGN KEY (`cno`) REFERENCES `category` (`cno`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (1,'목캔디',1200,'롯데','throatCandy.png','목아플때 먹는','10'),(2,'마우스',9700,'LG','lgMouse.png','컴퓨터 입력장치','20'),(3,'태양의 마테차',1700,'코카콜라','sun.png','다이어트할 때 좋아요','10'),(4,'울트라북',1500000,'삼성',NULL,NULL,'20'),(5,'이것이 자바다',30000,'한빛미디어','java.png',NULL,NULL),(6,'오후에 마시는 마테차',9000,'동글실업','afternoonTea.png',NULL,'10'),(7,'usb 마우스',12000,'삼성전자','usbmouse.png',NULL,'20'),(8,'사무용 데스크',85000,'PATRA','par_desk.png',NULL,'40'),(9,'핸디형선풍기',22000,'카카오프렌즈',NULL,NULL,'20');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:14
