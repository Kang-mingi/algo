-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_list`
--

DROP TABLE IF EXISTS `quiz_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `quiz_list` (
  `no` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `question` varchar(250) COLLATE utf8_bin NOT NULL,
  `answer_cnt` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ps_correct` varchar(250) COLLATE utf8_bin NOT NULL,
  `ps_wrong` varchar(250) COLLATE utf8_bin NOT NULL,
  `ans1` varchar(45) COLLATE utf8_bin NOT NULL,
  `ans2` varchar(45) COLLATE utf8_bin NOT NULL,
  `ans3` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `ans4` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_list`
--

LOCK TABLES `quiz_list` WRITE;
/*!40000 ALTER TABLE `quiz_list` DISABLE KEYS */;
INSERT INTO `quiz_list` VALUES (1,1,'신라면의 제조사는?',4,2,'농심 신~~라면! 아시죠??','농심 신~~라면! 아시죠??','삼양','농심','빙그레','오뚜기'),(2,1,'새우탕에 새우가 들어갈까?',2,2,'새우탕인데 당근빠따 들어가죠!','새우탕인데 당근빠따 들어가죠!','안들어가!','들어가!',NULL,NULL),(3,1,'2019년 라면 판매 1등 브랜드는?',4,4,'그래도 역시 신라면이네요!','아직은 신라면이라구요~','진라면','육개장','너구리','신라면'),(4,1,'다음 중 알러지 유발성분이 가장 많은 음식은?',4,3,'삼양라면이 알러지 성분인 대두, 땅콩, 우유, 돼지고기를 가지고 있네요!.','삼양라면이 알러지 성분인 대두, 땅콩, 우유, 돼지고기를 가지고 있네요!.','메로나','서울우유바나나','큰컵삼양라면','비타500칼슘'),(5,1,'다음 중 우유가 들어가지 않은 제품은?',4,3,'다음 문제는 좀 더 어려워집니다!','설마.. 이걸 틀렸어요?','칸타타프리미엄라떼	','맥심티오피마스터라떼','칸타타아메리카노','서울우유바나나'),(6,3,'죠스바에는 대두가 들어갈까?',2,1,'너 대두 ㅋㅋ<br/>들어갑니다!','너 대두 ㅋㅋ<br/>들어갑니다!','들어가!<br/> 왠지 들어가니까 물어봤을 거 같아','안 들어가!',NULL,NULL),(7,1,'다음 중 땅콩이 들어가지 않는 아이스크림은??',3,3,'비비비비빅! 비비빅!이죠~!','삐빅! 비비빅!입니다!','누크바','수박바','비비빅',NULL),(8,2,'다음 중 칼로리가 가장 높은 식품은?',4,4,'땅콩이 들어가서 누크바가 제일 높네요! <br> 누크바 : 274kcal<br>비비빅 : 186kcal<br>수박바 : 110kcal<br>죠스바 : 113kcal','땅콩이 들어가서 누크바가 제일 높네요! <br> 누크바 : 274kcal<br>비비빅 : 186kcal<br>수박바 : 110kcal<br>죠스바 : 113kcal','죠스바','수박바','비비빅','누크바'),(9,1,'육개장의 제조사는?',4,3,'정답! 농심 육개장입니다!','틀림ㅠ 농심 육개장입니다!','삼양','빙그레','농심','오뚜기'),(10,3,'아카페라아메리카노가 칸타타아메리카노보다 칼로리가 높다!',2,2,'어떻게 맞췄어요..? <br>칸타타아메리카노 : 80kcal<br> 아카페라아메리카노 : 58kcal','이걸 어케 맞춰 !!! <br>칸타타아메리카노 : 80kcal<br> 아카페라아메리카노 : 58kcal','그..럴껄?','아..닐껄?',NULL,NULL),(11,2,'누크바가 가진 알러지 종류는 무엇일까요?',2,2,'정답입니다 <br>누크바에 땅콩은 들어갔지만 대두는 안들어갔어요!','누크바에 땅콩은 들어갔지만 대두는 안들어갔어요!','대두','땅콩',NULL,NULL),(12,2,'두 라면 중 더 높은 칼로리를 가진 라면은?',2,1,'칼로리도 판매량도 높은 신라면~<br>신라면큰사발 : 347kcal <br> 큰컵삼양라면 : 272 kcal','칼로리도 판매량도 높은 신라면~<br>신라면 : 347kcal <br> 삼양라면 : 272 kcal','신라면 큰사발','큰컵삼양라면',NULL,NULL),(13,3,'두 라면 중 더 높은 칼로리를 가진 라면은?',2,2,'솔직히 찍었죠? <br> 큰컵삼양라면 : 272 kcal <br> 진라면컵 매운맛 : 275 kcal','못 맞출만 했다.. <br> 큰컵삼양라면 : 272 kcal <br> 진라면컵 매운맛 : 275 kcal','큰컵삼양라면','진라면컵매운맛',NULL,NULL),(14,2,'죠스바의 칼로리는 150 kcal가 넘는다?!',2,2,'정답입니다! <br>죠스바 : 113 kcal','틀렸습니다! <br> 죠스바 : 113kcal','넘지넘지~<br>먹어봐서 암','안넘지~<br>아이스크림이 150kcal가 넘겠어?',NULL,NULL),(15,2,'서울우유바나나의 \'제조사\'는 서울우유다!',2,2,'서울우유 바나나는 당연히 서울우유에서 만들었겠죠?','아니 서울우유 바나나는 서울우유에서 만들었겠죠?','아니야!','맞아!',NULL,NULL),(16,3,'다음 중 비타500의 제조사로 옳은 것은??',4,1,'이걸 맞추다니!','어렵죠?','광동제약','동서식품','cmg제약','동아제약'),(18,3,'롯데 칠성사이다에서 칠성의 유래로 알맞는 것은?',3,1,'정답! <br>7명의 성씨(姓氏)가 모여 주주를 이루고 처음의 칠성(七姓)이 탄생하게 되었습니다.','7명의 성씨(姓氏)가 모여 주주를 이루고 처음의 칠성(七姓)이 탄생하게 되었습니다.','7명의 성씨가 모여 주주를 구성해서!','롯데 기업의 7개의 별이 되기 위해!','칠성 창업자의 큰 아들 이름이 칠성이라서!',NULL),(19,2,'죠스바의 제조사는?',3,2,'맞습니다 <br> 죠스바는 롯데입니다~','죠스바는 롯데입니다~','농심','롯데','빙그레',NULL),(20,2,'메로나의 칼로리가 비비빅보다 높을까?',2,1,'정답입니다! <br> 비비빅 : 186 kcal<br>메로나 : 156 kcal<br>의외로 비비빅이 엄청 높네요!','틀렸어요! <br> 비비빅 : 186 kcal<br>메로나 : 156 kcal<br>의외로 비비빅이 엄청 높네요!','비비빅이 높다!','메로나가 높다!',NULL,NULL),(21,2,'메로나의 칼로리가 비비빅보다 높을까?',2,2,'정답입니다! <br> 비비빅 : 186 kcal<br>메로나 : 156 kcal<br>의외로 비비빅이 엄청 높네요!','틀렸어요! <br> 비비빅 : 186 kcal<br>메로나 : 156 kcal<br>의외로 비비빅이 엄청 높네요!','응!','아니!',NULL,NULL),(22,2,'두 라면 중 더 낮은 칼로리를 가진 라면은?',2,1,'정답입니다! 큰컵삼양라면이 더 낮아요!<br>신라면큰사발 : 347kcal <br> 큰컵삼양라면 : 272 kcal','큰컵삼양라면이 더 낮아요!<br>신라면큰사발 : 347kcal <br> 큰컵삼양라면 : 272 kcal','큰컵삼양라면','신라면큰사발',NULL,NULL),(23,2,'다음 중 롯데제과의 식품이 아닌 것은?',4,3,'맞았어요! 아카페라아메리카노는 빙그레에서 만들었습니다.','틀렸어요! 아카페라아메리카노는 빙그레에서 만들었습니다.','비타파워','수박바','아카페라아메리카노','누크바'),(24,1,'다음 중 식품의약품 안전처에서 지정해둔 알레르기 종류가 아닌 것은?',4,3,'맞았습니다! <br>알레르기는 메밀, 밀, 대두, 견과류, 육류, 갑각류, 토마토, 난류, 우유, 조개류, 굴, 전, 홍합, 아황산 포함식품입니다.','틀렸습니다! <br>알레르기는 메밀, 밀, 대두, 견과류, 육류, 갑각류, 토마토, 난류, 우유, 조개류, 굴, 전, 홍합, 아황산 포함식품입니다.','아황산 포함식품','토마토','배추','육류');
/*!40000 ALTER TABLE `quiz_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 13:54:12
